# Práctica TDD: `calcularDescuento(precio, porcentaje)`

## Estructura
```
tdd-descuento/
├── package.json
├── src/descuento.js          # Función implementada
├── test/descuento.test.js    # 12 pruebas unitarias (versión refactorizada)
└── evidencia/                # Salidas reales de cada fase
    ├── 1-rojo.txt            # 9/9 pruebas fallan (función sin implementar)
    ├── 2-verde.txt           # 9/9 pruebas pasan tras implementar
    ├── 3-refactor.txt        # 12/12 pasan tras refactorizar las pruebas
    └── 4-independencia.txt   # pruebas aisladas, orden inverso y 5 repeticiones
```

## Ejecutar (requiere Node 18+, sin dependencias)
```
npm test
```

## Ciclo TDD seguido
| Fase | Acción | Resultado |
|------|--------|-----------|
| 🔴 Rojo | Pruebas escritas antes que el código; función vacía | 0 pasan / 9 fallan |
| 🟢 Verde | Implementación mínima + validaciones | 9 pasan / 0 fallan |
| 🔵 Refactor | Pruebas guiadas por tabla de datos, `describe` anidados, nombres claros | 12 pasan / 0 fallan |

## Principios de una buena prueba aplicados
| Principio | Cómo se cumple |
|-----------|----------------|
| **Independencia** | Ninguna prueba usa estado compartido ni depende de otra. Comprobado ejecutando cada una sola y en orden inverso (`evidencia/4-independencia.txt`). |
| **Repetibilidad** | `calcularDescuento` es una función pura (sin fecha, azar, red ni disco). 5 ejecuciones seguidas dieron el mismo resultado. |
| **Atomicidad** | Cada `test` verifica un único comportamiento con una sola aserción principal. |
| **Claridad** | Nombres que describen entrada y resultado esperado; estructura Arrange-Act-Assert; casos expresados como tabla. |
| **Automatización** | `npm test` ejecuta todo sin intervención y devuelve código de salida distinto de 0 si algo falla. |

## Aserciones usadas
- `assert.equal(resultado, esperado)` para valores calculados.
- `assert.throws(fn, TipoDeError)` para entradas inválidas.