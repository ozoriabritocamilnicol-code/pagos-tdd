/**
 * Calcula el precio final tras aplicar un descuento porcentual.
 * Función pura: sin estado global, sin efectos secundarios (repetible).
 *
 * @param {number} precio      Precio original (>= 0)
 * @param {number} porcentaje  Descuento entre 0 y 100
 * @returns {number}           Precio con descuento aplicado
 */
function calcularDescuento(precio, porcentaje) {
  if (typeof precio !== 'number' || typeof porcentaje !== 'number' ||
      Number.isNaN(precio) || Number.isNaN(porcentaje)) {
    throw new TypeError('precio y porcentaje deben ser números');
  }
  if (precio < 0) {
    throw new RangeError('el precio no puede ser negativo');
  }
  if (porcentaje < 0 || porcentaje > 100) {
    throw new RangeError('el porcentaje debe estar entre 0 y 100');
  }
  return precio - (precio * porcentaje) / 100;
}

module.exports = { calcularDescuento };