const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const { calcularDescuento } = require('../src/descuento');

// Cada caso es un dato: la prueba se lee como una tabla de la especificación.
const casosValidos = [
  { nombre: 'sin descuento (0%) devuelve el precio original', precio: 1000, descuento: 0,   esperado: 1000 },
  { nombre: 'descuento 10% sobre 1000 devuelve 900',           precio: 1000, descuento: 10,  esperado: 900  },
  { nombre: 'descuento 20% sobre 500 devuelve 400',            precio: 500,  descuento: 20,  esperado: 400  },
  { nombre: 'precio cero siempre devuelve 0',                  precio: 0,    descuento: 10,  esperado: 0    },
  { nombre: 'descuento máximo (100%) devuelve 0',              precio: 1000, descuento: 100, esperado: 0    },
  { nombre: 'descuento con decimales: 50% sobre 99.99',        precio: 99.99, descuento: 50, esperado: 49.995 },
];

// Cada entrada inválida: [nombre, precio, descuento, tipo de error esperado]
const casosInvalidos = [
  { nombre: 'descuento mayor a 100% lanza RangeError', precio: 1000,   descuento: 101,  error: RangeError },
  { nombre: 'descuento negativo lanza RangeError',     precio: 1000,   descuento: -5,   error: RangeError },
  { nombre: 'precio negativo lanza RangeError',        precio: -100,   descuento: 10,   error: RangeError },
  { nombre: 'precio no numérico lanza TypeError',      precio: '1000', descuento: 10,   error: TypeError  },
  { nombre: 'descuento NaN lanza TypeError',           precio: 1000,   descuento: NaN,  error: TypeError  },
];

describe('calcularDescuento(precio, porcentaje)', () => {
  describe('con entradas válidas', () => {
    for (const { nombre, precio, descuento, esperado } of casosValidos) {
      test(nombre, () => {
        // Arrange: los datos vienen del caso; Act + Assert
        const resultado = calcularDescuento(precio, descuento);
        assert.equal(resultado, esperado);
      });
    }

    test('es repetible: dos llamadas idénticas dan el mismo resultado', () => {
      assert.equal(calcularDescuento(1000, 10), calcularDescuento(1000, 10));
    });
  });

  describe('con entradas inválidas', () => {
    for (const { nombre, precio, descuento, error } of casosInvalidos) {
      test(nombre, () => {
        assert.throws(() => calcularDescuento(precio, descuento), error);
      });
    }
  });
});